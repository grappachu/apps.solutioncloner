using System;
using System.Threading.Tasks;

namespace Grappachu.Templates.NugetLibrary
{
    public class TestLib
    {
        /// <summary>
        /// https://docs.microsoft.com/it-it/dotnet/core/tutorials/libraries
        /// </summary>
        /// <returns></returns>
        public static bool Test()
        {
            #if !NET40
            Task.Run(() => { Console.WriteLine("ok"); });
            #endif
            return true;
        }
    }
}
