using SharpTestsEx;
using Xunit;

namespace Grappachu.Templates.NugetLibrary.Test
{
    public class UnitTest1
    {
        [Fact]
        public void FooTest()
        {
            var res = TestLib.Test();

            res.Should().Be.True();
        }
    }
}
