using SharpTestsEx;
using Xunit;

namespace Grappachu.Templates.NugetLibrary
{
    public class UnitTest1
    {
        [Fact(DisplayName = "A foo-test running on an edge framework (netstandard 2.0)")]
        public void FooTest()
        {
            var res = TestLib.Test();

            res.Should().Be.True();
        }
    }
}