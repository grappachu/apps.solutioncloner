![Logo of the project](§{icon-url})

----
# §{product-title}

§{product-description}

## Dependencies 

> List here all dependencies and pre-requirements for running this project

## Installing / Getting started

> Describe how this software should be used in the basic case

## Features

Provide a small list of things a user can do with this software:

- ...

## Contributing

> Contributing guidelines here


## Links

> Add all useful project links here

- Project homepage: [§{project-url}](§{project-url})
- Repository:  [§{repository-url}](§{repository-url})
- License:  [§{license-url}](§{license-url})



