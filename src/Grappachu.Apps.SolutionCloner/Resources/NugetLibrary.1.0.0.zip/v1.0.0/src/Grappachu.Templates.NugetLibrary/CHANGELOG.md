# §{product-title} - Changelog

All notable changes to this project will be documented in this file.

This project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

> Some useful links about how to keep a changelog can be found here:
 - [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)
 - [Michael Klishin](https://github.com/michaelklishin/langohr/blob/master/ChangeLog.md)



## Changes between §{product-title} 1.1.x and 1.2.0 (unreleased)

No changes yet.


## Changes between §{product-title} 1.0.x and 1.1.0 (unreleased)

### Added

- Library can now accomplish to this awesome task: [feature#103](https://your-work-tracker/product/feature/103)
- Italian translations from [§{author}](§{project-url}/§{author}) 

### Changed

- `GitVersionTask` dependency has been update to `4.1.0`
- License of the project has moved to [MIT](https://opensource.org/licenses/MIT)
- Start following [SemVer](https://semver.org) properly.


## Changes between §{product-title} 1.0.0 and 1.0.1 (§{today})

### Fixed

- Package icon is now displayed on NuGet: [issue#269](https://your-issue-tracker/product/issues/269)


## Released §{product-title} 1.0.0 (§{today})

### Added

- Created this awesome library by [§{author}](§{project-url})

