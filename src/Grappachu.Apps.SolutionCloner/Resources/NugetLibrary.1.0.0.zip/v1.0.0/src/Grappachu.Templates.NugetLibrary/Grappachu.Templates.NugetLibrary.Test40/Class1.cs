namespace Grappachu.Templates.NugetLibrary.Test40
{
    public sealed class SampleTest
    {
        public SampleTest()
        {
            TestLib.Test();
        }
    }
}
