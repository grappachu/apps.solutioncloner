namespace Grappachu.Templates.NugetLibrary.Test40
{
    /// <summary>
    ///     This can be a sample project or a test project for older frameworks...
    ///     ...however <c>xunit</c> does not support framework 4.0 anymore.
    /// </summary>
    public sealed class SampleTest
    {
        public SampleTest()
        {
            TestLib.Test();
        }
    }
}