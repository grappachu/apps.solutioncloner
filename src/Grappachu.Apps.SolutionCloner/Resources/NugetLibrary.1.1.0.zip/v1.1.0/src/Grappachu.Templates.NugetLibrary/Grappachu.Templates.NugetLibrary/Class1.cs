using System;

#if !NET40
using System.Threading.Tasks;
#endif

namespace Grappachu.Templates.NugetLibrary
{
    /// <summary>
    ///     This is a sample class to demonstrate how package works.
    ///     In the test method we use the preprocessor directive <c>NET40</c> to handle legacy code (.NET Framework 4.0)
    ///     Test40 is the legacy test project to coverage of unsupported.
    ///     If you don't need support for old framework you can delete the project then manually edit the .csproj file to
    ///     cleanup all references.
    /// </summary>
    public static class TestLib
    {
        /// <summary>
        ///     https://docs.microsoft.com/it-it/dotnet/core/tutorials/libraries
        /// </summary>
        /// <returns></returns>
        public static bool Test()
        {
#if !NET40
            Task.Run(() => { Console.WriteLine(@".NET 4.5+ have tasks... :-) "); });
#else
            Console.WriteLine(@".NET 4.0 don't have tasks... :-( ");
#endif
            return true;
        }
    }
}